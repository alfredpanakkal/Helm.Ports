# Ports Explorer

A web front end for [tayljordan/ports](https://github.com/tayljordan/ports) — a JSON dataset of
**5,410 worldwide maritime ports** derived from the NGA Publication 150 *World Port Index*
(2019 edition).

Search ports by name, country, or WPI ID; filter by size, vessel limits, channel depth, tidal
range, and entrance restrictions; browse results in a sortable table or on an interactive world
map with zoom-based level of detail.

![List view](docs/screenshot-list.png)
![Map view with level of detail](docs/screenshot-map.png)

## Features

- **Search** across port name, country, state/region, point of interest, and WPI ID (debounced)
- **Filters**
  - Country (209 normalized countries & territories)
  - Port size (Major / Small / Minor / Very Small / unclassified)
  - Max vessel size (large / medium / unknown)
  - Minimum channel depth — vessel draft screening
  - Mean tidal range window (min–max slider)
  - Entrance restrictions (tide, heavy swell, ice, other)
- **Table view** — sortable on six columns (null-safe, nulls always last), paginated 10–100 rows
- **Map view** — custom SVG world map, no tile server or map library required
  - Zoom-based **level of detail (LOD)**: ports are tiered by WPI harbor size and tiers appear as
    you zoom in (see below)
  - Viewport culling at every zoom level
  - Dots colored by max channel depth, sized by port tier
  - Wheel zoom, drag pan, hover tooltips, click for details
- **Port detail panel** — location, all four depth ranges (channel / anchorage / cargo pier /
  oil terminal), mean tidal range, restrictions, dataset attribution
- Light/dark theme, responsive layout (filters become a drawer on mobile), sticky footer,
  accessibility labels throughout

## Quick start

Requires Node.js 20+ (or [Bun](https://bun.sh) 1.1+).

```bash
npm install
npm run dev
```

Open http://localhost:3000.

The dataset ships with the repo at `data/ports.json`, so no extra setup is needed. To refresh it
from upstream:

```bash
curl -sL https://raw.githubusercontent.com/tayljordan/ports/main/ports.json -o data/ports.json
```

### Other scripts

```bash
npm run lint   # ESLint
npm run build  # production build (standalone output)
npm start      # serve the production build
```

## How it works

### Architecture

```
data/ports.json          5,410 port records (WPI), read once and cached in memory
src/lib/ports.ts         typed data layer: loading, country-name normalization, tier + rank helpers
src/app/api/ports/       GET /api/ports       — search / filter / sort / paginate
                         GET /api/ports/:id   — single port
                         GET /api/ports?format=points — compact payload for the map
src/app/api/stats/       GET /api/stats — dataset totals, size/vessel counts, top countries
src/app/page.tsx         single-page UI (hero + stats, filters, list/map tabs)
src/components/ports/    FilterSidebar, PortsTable, PortMap, PortDetailSheet, shared types
public/land.json         world coastlines as SVG path strings (equirectangular, viewBox 1000x500)
```

Everything runs server-side from the one JSON file; there is no database. The data layer caches
the parsed array in module scope, so API routes filter in memory per request (fast enough for
5.4k records by a wide margin).

### Country normalization

The upstream data uses WPI-style abbreviations (`U.S.A.`, `U.K.`, `Cape Verde Is.`,
`Virgin Is. (U.K.)`, …). `src/lib/ports.ts` maps these to clean names and merges variants
(e.g. `Cook Is.` + `Cook Islands`), which reduces 220 raw country strings to 209 countries.
`scripts/check_countries.py` re-runs the audit that produced the mapping.

### Zoom-based level of detail (LOD)

Rendering 5,410 dots at once is wasteful and unreadable, so the map tags every port with a tier
derived from the WPI `port_size` field and only mounts the tiers that suit the current zoom:

| Map scale k | Tiers shown | Approx. count (unfiltered) |
|---|---|---|
| 1 (world) | tier 1 — Major | 160 |
| ≥ 2 | + tier 2 — Small | 1,137 |
| ≥ 4 | + tier 3 — Minor | 1,499 |
| ≥ 8 | + tier 4 — Very Small / unclassified | 5,410 |

- Tiers are assigned server-side (`t` field in the points payload) and split into four arrays
  on the client once per data change.
- Tier visibility is recomputed on every view change; only dots inside the visible map
  rectangle are mounted (viewport culling), so local zoom is cheap even with all tiers active.
- Tier 1 paints last so major ports always read on top.
- Dot radius scales with tier, so major ports are visually prominent.
- The selected port stays visible and highlighted (teal ring) even when its tier is hidden.

Both knobs live in `src/components/ports/PortMap.tsx` and are meant to be tuned on a real
device:

```ts
const LOD_MIN_ZOOM = [1, 2, 4, 8];        // min scale k at which each tier appears
const TIER_RADIUS  = [3.4, 2.4, 1.8, 1.4]; // base dot radius per tier
```

### Regenerating the coastlines

`public/land.json` is built from [Natural Earth](https://www.naturalearthdata.com/) 1:110m
admin-0 countries (public domain), projected to equirectangular coordinates and simplified:

```bash
curl -sL https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson -o /tmp/world.geojson
python3 scripts/gen_land_paths.py   # writes public/land.json
```

## Data source & attribution

- **Ports dataset**: [tayljordan/ports](https://github.com/tayljordan/ports) (MIT license),
  compiled from the NGA Publication 150 *World Port Index*, 2019 edition.
- **Coastlines**: Natural Earth (public domain).
- Depth values represent a single recorded sounding and do not account for shifting bottom
  conditions, dredging, or seasonal variation. **This app is not a substitute for current
  nautical charts or Notices to Mariners.**

## License

Application code: MIT. Port data: MIT via tayljordan/ports (NGA World Port Index). Map data:
Natural Earth, public domain.
