import json
import re
from collections import Counter

with open('/home/z/my-project/data/ports.json') as f:
    ports = json.load(f)['ports']

c = Counter(p.get('country') for p in ports if p.get('country'))
names = sorted(c.keys())

def norm_candidate(n):
    # strip trailing 'Is.' style abbreviations for grouping check only
    return re.sub(r'[^A-Za-z]', '', n).lower()

# group by normalized to spot same-country variants
groups = {}
for n in names:
    groups.setdefault(norm_candidate(n), []).append(n)

for k, v in sorted(groups.items()):
    if len(v) > 1:
        print(v, [c[x] for x in v])

# also show any countries whose name ends with 'Is' variants vs full names
print('---')
for n in names:
    if 'Is' in n or 'Islands' in n:
        print(n, c[n])
