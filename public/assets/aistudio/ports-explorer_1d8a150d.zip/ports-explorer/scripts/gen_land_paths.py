#!/usr/bin/env python3
"""Convert Natural Earth countries geojson into a compact JSON of SVG path
strings in equirectangular projection (viewBox 0 0 1000 500).

Output: /home/z/my-project/public/land.json  { "paths": ["M...", ...] }
Coordinate mapping: x = (lon + 180) / 360 * 1000, y = (90 - lat) / 180 * 500
"""
import json

W, H = 1000.0, 500.0

def project(lon, lat):
    return ((lon + 180.0) / 360.0 * W, (90.0 - lat) / 180.0 * H)

def fmt(v):
    r = round(v, 1)
    if r == int(r):
        return str(int(r))
    return str(r)

def ring_to_path(ring):
    pts = []
    prev = None
    for lon, lat in ring:
        x, y = project(lon, lat)
        if prev is not None and abs(x - prev[0]) < 0.15 and abs(y - prev[1]) < 0.15:
            continue
        pts.append((x, y))
        prev = (x, y)
    if len(pts) < 3:
        return None
    d = f"M{fmt(pts[0][0])} {fmt(pts[0][1])}"
    for x, y in pts[1:]:
        d += f"L{fmt(x)} {fmt(y)}"
    d += "Z"
    return d

def main():
    with open("/tmp/world.geojson") as f:
        gj = json.load(f)
    paths = []
    for feat in gj["features"]:
        geom = feat["geometry"]
        if geom is None:
            continue
        polys = []
        if geom["type"] == "Polygon":
            polys = [geom["coordinates"]]
        elif geom["type"] == "MultiPolygon":
            polys = geom["coordinates"]
        for poly in polys:
            for ring in poly:
                d = ring_to_path(ring)
                if d:
                    paths.append(d)
    out = {"paths": paths}
    with open("/home/z/my-project/public/land.json", "w") as f:
        json.dump(out, f, separators=(",", ":"))
    total_len = sum(len(p) for p in paths)
    print(f"rings: {len(paths)}, total chars: {total_len}")

if __name__ == "__main__":
    main()
