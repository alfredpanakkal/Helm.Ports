import { NextRequest, NextResponse } from "next/server";
import { getPorts } from "@/lib/ports";

export const dynamic = "force-dynamic";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const portId = parseInt(id, 10);
  if (isNaN(portId)) {
    return NextResponse.json({ error: "Invalid port ID" }, { status: 400 });
  }
  const port = getPorts().find((p) => p.wpi_port_id === portId);
  if (!port) {
    return NextResponse.json({ error: "Port not found" }, { status: 404 });
  }
  return NextResponse.json(port);
}
