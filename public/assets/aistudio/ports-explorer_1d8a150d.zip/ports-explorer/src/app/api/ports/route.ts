import { NextRequest, NextResponse } from "next/server";
import { getPorts, portSizeRank, portTier, vesselSizeRank, type PortRecord } from "@/lib/ports";

export const dynamic = "force-dynamic";

const SORTABLE = new Set([
  "wpi_port_name",
  "country",
  "port_size",
  "max_vessel_size",
  "channel_depth_max_m",
  "mean_tidal_range_m",
  "latitude",
  "longitude",
]);

function parseList(param: string | null): string[] {
  if (!param) return [];
  return param
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

function matchesQuery(p: PortRecord, q: string): boolean {
  const needle = q.toLowerCase();
  return (
    p.wpi_port_name.toLowerCase().includes(needle) ||
    p.country.toLowerCase().includes(needle) ||
    (p.state?.toLowerCase().includes(needle) ?? false) ||
    (p.point_of_interest?.toLowerCase().includes(needle) ?? false) ||
    String(p.wpi_port_id).includes(needle)
  );
}

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const q = sp.get("q")?.trim() ?? "";
  const countries = parseList(sp.get("country"));
  const portSizes = parseList(sp.get("portSize"));
  const vesselSizes = parseList(sp.get("vesselSize"));
  const minChannelDepth = sp.get("minChannelDepth") ? Number(sp.get("minChannelDepth")) : null;
  const minTidalRange = sp.get("minTidalRange") ? Number(sp.get("minTidalRange")) : null;
  const maxTidalRange = sp.get("maxTidalRange") ? Number(sp.get("maxTidalRange")) : null;
  const restrictions = parseList(sp.get("restriction")); // tide|swell|ice|other
  const sort = sp.get("sort") ?? "wpi_port_name";
  const order = sp.get("order") === "desc" ? -1 : 1;
  const page = Math.max(1, parseInt(sp.get("page") ?? "1", 10) || 1);
  const pageSize = Math.min(100, Math.max(10, parseInt(sp.get("pageSize") ?? "25", 10) || 25));
  const format = sp.get("format"); // "points" → compact map payload

  const all = getPorts();
  const countrySet = countries.length ? new Set(countries) : null;
  const portSizeSet = portSizes.length ? new Set(portSizes) : null;
  const vesselSizeSet = vesselSizes.length ? new Set(vesselSizes) : null;
  const restrSet = new Set(restrictions);

  let filtered = all.filter((p) => {
    if (q && !matchesQuery(p, q)) return false;
    if (countrySet && !countrySet.has(p.country)) return false;
    if (portSizeSet) {
      const key = p.port_size ?? "none";
      if (!portSizeSet.has(key)) return false;
    }
    if (vesselSizeSet) {
      const key = p.max_vessel_size ?? "unknown";
      if (!vesselSizeSet.has(key)) return false;
    }
    if (minChannelDepth != null && !isNaN(minChannelDepth)) {
      const d = p.channel_depth_max_m;
      if (d == null || d < minChannelDepth) return false;
    }
    if (minTidalRange != null && !isNaN(minTidalRange)) {
      const t = p.mean_tidal_range_m;
      if (t == null || t < minTidalRange) return false;
    }
    if (maxTidalRange != null && !isNaN(maxTidalRange)) {
      const t = p.mean_tidal_range_m;
      if (t == null || t > maxTidalRange) return false;
    }
    if (restrSet.has("tide") && !p.entrance_restriction_tide) return false;
    if (restrSet.has("swell") && !p.entrance_restriction_heavy_swell) return false;
    if (restrSet.has("ice") && !p.entrance_restriction_ice) return false;
    if (restrSet.has("other") && !p.entrance_restriction_other) return false;
    return true;
  });

  const sortKey = SORTABLE.has(sort) ? sort : "wpi_port_name";
  filtered = [...filtered].sort((a, b) => {
    let cmp: number;
    if (sortKey === "port_size") {
      const ra = portSizeRank(a.port_size);
      const rb = portSizeRank(b.port_size);
      if (ra === 0) return 1; // unclassified last, regardless of direction
      if (rb === 0) return -1;
      cmp = ra - rb;
    } else if (sortKey === "max_vessel_size") {
      const ra = vesselSizeRank(a.max_vessel_size);
      const rb = vesselSizeRank(b.max_vessel_size);
      if (ra === 0) return 1;
      if (rb === 0) return -1;
      cmp = ra - rb;
    } else {
      const av = (a[sortKey as keyof PortRecord] as number | string | null) ?? null;
      const bv = (b[sortKey as keyof PortRecord] as number | string | null) ?? null;
      if (av === null && bv === null) cmp = 0;
      else if (av === null) return 1; // nulls always last, regardless of direction
      else if (bv === null) return -1;
      else if (typeof av === "number" && typeof bv === "number") cmp = av - bv;
      else cmp = String(av).localeCompare(String(bv));
    }
    return cmp * order;
  });

  const total = filtered.length;

  if (format === "points") {
    const points = filtered.map((p) => ({
      i: p.wpi_port_id,
      n: p.wpi_port_name,
      c: p.country,
      la: p.latitude,
      lo: p.longitude,
      d: p.channel_depth_max_m,
      t: portTier(p.port_size),
    }));
    return NextResponse.json({ total, points });
  }

  const start = (page - 1) * pageSize;
  const items = filtered.slice(start, start + pageSize);

  return NextResponse.json({ total, page, pageSize, items });
}
