import { NextResponse } from "next/server";
import { getPorts, getCountryCounts, getMetadata } from "@/lib/ports";

export const dynamic = "force-dynamic";

export async function GET() {
  const ports = getPorts();
  const meta = getMetadata();
  const countryCounts = getCountryCounts();

  let withDepth = 0;
  let withTidal = 0;
  let withRestrictions = 0;
  const sizeCounts = new Map<string, number>();
  const vesselCounts = new Map<string, number>();
  const maxDepths: number[] = [];

  for (const p of ports) {
    if (p.channel_depth_max_m != null) {
      withDepth++;
      maxDepths.push(p.channel_depth_max_m);
    }
    if (p.mean_tidal_range_m != null) withTidal++;
    if (
      p.entrance_restriction_tide ||
      p.entrance_restriction_heavy_swell ||
      p.entrance_restriction_ice ||
      p.entrance_restriction_other
    ) {
      withRestrictions++;
    }
    const sk = p.port_size ?? "Unclassified";
    sizeCounts.set(sk, (sizeCounts.get(sk) ?? 0) + 1);
    const vk = p.max_vessel_size ?? "Unknown";
    vesselCounts.set(vk, (vesselCounts.get(vk) ?? 0) + 1);
  }

  // channel depth histogram (0–25 m in 5 m bins + >25)
  const bins = [0, 0, 0, 0, 0, 0];
  for (const d of maxDepths) {
    const idx = d > 25 ? 5 : Math.min(4, Math.floor(d / 5));
    bins[idx]++;
  }

  return NextResponse.json({
    meta,
    totalPorts: ports.length,
    totalCountries: countryCounts.length,
    withDepth,
    withTidal,
    withRestrictions,
    sizeCounts: [...sizeCounts.entries()].sort((a, b) => b[1] - a[1]),
    vesselCounts: [...vesselCounts.entries()].sort((a, b) => b[1] - a[1]),
    topCountries: countryCounts.slice(0, 10),
    allCountries: countryCounts,
    depthBins: bins,
  });
}
