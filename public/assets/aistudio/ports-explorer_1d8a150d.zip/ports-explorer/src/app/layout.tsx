import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { QueryProvider } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Ports Explorer — World Port Index",
  description:
    "Search, filter, and map 5,410 worldwide maritime ports with depth soundings, tidal ranges, entrance restrictions, and vessel size limits. Powered by the tayljordan/ports dataset (NGA World Port Index).",
  keywords: [
    "maritime ports",
    "World Port Index",
    "port depths",
    "tidal range",
    "nautical",
    "harbors",
  ],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Ports Explorer — World Port Index",
    description:
      "Search, filter, and map 5,410 worldwide maritime ports with depth soundings, tidal ranges and entrance restrictions.",
    siteName: "Ports Explorer",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <QueryProvider>
          <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
            {children}
            <Toaster />
          </ThemeProvider>
        </QueryProvider>
      </body>
    </html>
  );
}
